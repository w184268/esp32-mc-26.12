// SPDX-License-Identifier: GPL-3.0-only
// Attribution and modification details are documented in ../../NOTICE.

#include "packet_codec.h"
#include <string.h>

// ======================== 驱动层 (平台相关) ========================
#ifdef _WIN32
#include "win_platform.h"
#else
#include <Arduino.h>
#include <errno.h>
#include <lwip/sockets.h>       // [驱动] ESP32 lwIP socket
#include <freertos/FreeRTOS.h>
#include <freertos/task.h>      // [驱动] FreeRTOS vTaskDelay
#endif
// ======================== 驱动层结束 ========================

namespace {
const uint8_t SEGMENT_BITS = 0x7F;
const uint8_t CONTINUE_BIT = 0x80;
}

PacketCodec::PacketCodec(int fd) : fd_(fd) {}

bool PacketCodec::readExact(uint8_t* buf, size_t len) {
  size_t done = 0;
  uint32_t start = millis();
  while (done < len) {
    if (fd_ < 0) return false;
#ifdef _WIN32
    int n = recv((SOCKET)fd_, (char*)(buf + done), (int)(len - done), 0);
    if (n > 0) { done += (size_t)n; start = millis(); continue; }
    if (n == 0) return false;
    int err = WSAGetLastError();
    if (err == WSAEWOULDBLOCK || err == WSAEINTR) {
      if (millis() - start > 5000) return false;
      Sleep(1);
      continue;
    }
#else
    int n = recv(fd_, buf + done, len - done, 0);  // [驱动] lwIP recv
    if (n > 0) { done += (size_t)n; start = millis(); continue; }
    if (n == 0) return false;
    if (errno == EAGAIN || errno == EWOULDBLOCK || errno == EINTR) {
      if (millis() - start > 5000) return false;
      vTaskDelay(1);  // [驱动] 让出 CPU 给 WiFi 任务
      continue;
    }
#endif
    return false;
  }
  return true;
}

bool PacketCodec::writeExact(const uint8_t* buf, size_t len) {
  size_t done = 0;
  uint32_t start = millis();
  while (done < len) {
    if (fd_ < 0) return false;
    size_t chunk = len - done;
    if (chunk > 1460) chunk = 1460;  // MTU 分片
#ifdef _WIN32
    int n = send((SOCKET)fd_, (const char*)(buf + done), (int)chunk, 0);
    if (n > 0) { done += (size_t)n; start = millis(); continue; }
    if (n == 0) return false;
    int err = WSAGetLastError();
    if (err == WSAEWOULDBLOCK || err == WSAEINTR) {
      if (millis() - start > 5000) return false;
      Sleep(1);
      continue;
    }
#else
    int n = send(fd_, buf + done, chunk, MSG_NOSIGNAL);  // [驱动] lwIP send
    if (n > 0) { done += (size_t)n; start = millis(); continue; }
    if (n == 0) return false;
    if (errno == EAGAIN || errno == EWOULDBLOCK || errno == EINTR) {
      if (millis() - start > 5000) return false;
      vTaskDelay(1);  // [驱动] 让出 CPU 给 WiFi 任务
      continue;
    }
#endif
    return false;
  }
  return true;
}

bool PacketCodec::readByte(uint8_t& value) { return readExact(&value, 1); }
bool PacketCodec::writeByte(uint8_t value) { return writeExact(&value, 1); }

bool PacketCodec::readUint16(uint16_t& value) {
  uint8_t buf[2];
  if (!readExact(buf, 2)) return false;
  value = ((uint16_t)buf[0] << 8) | buf[1];
  return true;
}
bool PacketCodec::writeUint16(uint16_t value) {
  uint8_t buf[2] = {(uint8_t)(value >> 8), (uint8_t)value};
  return writeExact(buf, 2);
}

bool PacketCodec::readUint32(uint32_t& value) {
  uint8_t buf[4];
  if (!readExact(buf, 4)) return false;
  value = ((uint32_t)buf[0] << 24) | ((uint32_t)buf[1] << 16) | ((uint32_t)buf[2] << 8) | buf[3];
  return true;
}
bool PacketCodec::writeUint32(uint32_t value) {
  uint8_t buf[4] = {(uint8_t)(value >> 24), (uint8_t)(value >> 16), (uint8_t)(value >> 8), (uint8_t)value};
  return writeExact(buf, 4);
}

bool PacketCodec::readUint64(uint64_t& value) {
  uint8_t buf[8];
  if (!readExact(buf, 8)) return false;
  value = ((uint64_t)buf[0] << 56) | ((uint64_t)buf[1] << 48) | ((uint64_t)buf[2] << 40) | ((uint64_t)buf[3] << 32) |
          ((uint64_t)buf[4] << 24) | ((uint64_t)buf[5] << 16) | ((uint64_t)buf[6] << 8) | (uint64_t)buf[7];
  return true;
}
bool PacketCodec::writeUint64(uint64_t value) {
  uint8_t buf[8] = {
    (uint8_t)(value >> 56), (uint8_t)(value >> 48), (uint8_t)(value >> 40), (uint8_t)(value >> 32),
    (uint8_t)(value >> 24), (uint8_t)(value >> 16), (uint8_t)(value >> 8), (uint8_t)value};
  return writeExact(buf, 8);
}

bool PacketCodec::readFloat(float& value) {
  uint32_t bits; if (!readUint32(bits)) return false;
  memcpy(&value, &bits, 4); return true;
}
bool PacketCodec::writeFloat(float value) {
  uint32_t bits; memcpy(&bits, &value, 4); return writeUint32(bits);
}
bool PacketCodec::readDouble(double& value) {
  uint64_t bits; if (!readUint64(bits)) return false;
  memcpy(&value, &bits, 8); return true;
}
bool PacketCodec::writeDouble(double value) {
  uint64_t bits; memcpy(&bits, &value, 8); return writeUint64(bits);
}

bool PacketCodec::readVarInt(int32_t& value) {
  value = 0; int position = 0;
  while (true) {
    uint8_t byte = 0;
    if (!readExact(&byte, 1)) return false;
    value |= (byte & SEGMENT_BITS) << position;
    if ((byte & CONTINUE_BIT) == 0) return true;
    position += 7;
    if (position >= 32) return false;
  }
}

bool PacketCodec::writeVarInt(uint32_t value) {
  uint8_t out[5]; size_t len = 0;
  do { uint8_t byte = value & SEGMENT_BITS; value >>= 7; if (value) byte |= CONTINUE_BIT; out[len++] = byte; } while (value);
  return writeExact(out, len);
}

int PacketCodec::sizeVarInt(uint32_t value) const {
  int size = 1; while ((value & ~SEGMENT_BITS) != 0) { value >>= 7; size++; } return size;
}

bool PacketCodec::readString(char* out, size_t out_len) {
  int32_t len = 0;
  if (!readVarInt(len) || len < 0 || out_len == 0) return false;
  size_t need = (size_t)len, copy_len = need;
  if (copy_len >= out_len) copy_len = out_len - 1;
  if (copy_len > 0 && !readExact((uint8_t*)out, copy_len)) return false;
  out[copy_len] = '\0';
  if (need > copy_len && !skipBytes(need - copy_len)) return false;
  return true;
}

bool PacketCodec::writeString(const char* str) {
  size_t len = strlen(str);
  return writeVarInt((uint32_t)len) && writeExact((const uint8_t*)str, len);
}

bool PacketCodec::skipString() {
  int32_t len = 0;
  if (!readVarInt(len) || len < 0) return false;
  return skipBytes((size_t)len);
}

bool PacketCodec::skipBytes(size_t len) {
  uint8_t tmp[64];
  while (len > 0) { size_t chunk = len > 64 ? 64 : len; if (!readExact(tmp, chunk)) return false; len -= chunk; }
  return true;
}
