// SPDX-License-Identifier: GPL-3.0-only
// Attribution and modification details are documented in ../NOTICE.

#ifndef CRAFTING_H
#define CRAFTING_H

#include "game_types.h"

void getCraftingOutput(PlayerData *player, uint8_t *count, uint16_t *item);
void getSmeltingOutput(PlayerData *player);

#endif
