# ESP32MC Server

编译！烧录！上电！一个 Minecraft Java 服务器就跑在 ESP32S3 上了。

进入世界，你可以移动、挖掘、放置、合成，看起来就像一台普通的 MC 服务器。但这一切，竟然运行在一块内存只有 **512KB** 的单片机上。

Java 本体都装不进去，它到底是怎么让 Minecraft 客户端连上的？

没开玩笑，这个项目直接实现了 Minecraft 服务端需要的网络协议、数据包处理和基础游戏逻辑。

ESP32MC 主要面向 Arduino ESP32S3，协议版本是 **26.1.2 / 775**。它不只是一个能玩的掌上服务器，更是一个用来学习 Minecraft 服务端底层原理的教学项目。

## 这个项目能学到什么

我们不会只停留在“把固件烧进去就能玩”。顺着代码往下看，你可以了解：

- Minecraft 客户端怎样与服务器建立连接
- 服务端怎样接收、拆分和发送网络数据包
- 数据包长度、包 ID、VarInt、字符串和 Payload 是什么
- Handshake、Status、Login、Play 等协议状态怎样切换
- 玩家登录、出生、移动和聊天怎样处理
- 方块、背包、合成、地形、Mob 和 Tick 怎样运行
- ESP32S3 怎样在有限内存下保存世界与玩家状态

项目尽量使用直接、可追踪的实现。遇到问题时可以顺着数据流找下去，而不是一头扎进层层封装里。

当前主线代码以 [code/](code/) 目录为准。

## 开源许可与来源

ESP32MC 是基于 [p2r3/bareiron](https://github.com/p2r3/bareiron) 修改和重构的派生项目。

原始部分的版权归 bareiron 作者和贡献者所有。ESP32MC 的新增与修改部分由 GYGKHD 于 2026 年完成，主要包括：

- 移植到 Arduino ESP32S3 环境
- 将服务器主体重构为 C++ 类和独立模块
- 重写网络层与数据包编解码层
- 适配 Minecraft Java 26.1.2 / 775 协议
- 增加 WiFi 配网、连接调度、内存保护和 Windows 调试支持
- 调整地形、物品、生物和其他游戏逻辑

整个派生项目按照 **GNU General Public License Version 3** 发布。你可以使用、研究、修改和再发布本项目，但再发布时必须继续遵守 GPLv3，并提供相应源码。

完整许可证见 [LICENSE](LICENSE)，来源和修改声明见 [NOTICE](NOTICE)。

## 项目定位

这个项目首先是用来教学和研究 Minecraft 服务端运行机制的，其次才是一台可以实际进入世界游玩的极简服务器。

它不是完整原版服，也不以高并发和插件兼容为目标。相比堆满功能，这里更关心：

- 在 ESP32S3 上把服务器真正跑起来
- 让协议和游戏逻辑看得见、找得到
- 方便在课程中拆开讲解和动手实验
- 出现问题时能直接定位到对应的数据包或逻辑

## 当前能力

现在已经实现的内容包括：

- 玩家登录、出生、移动和聊天
- 基础区块生成、地形和生物群系
- 方块放置、破坏和简单流体
- 背包、基础合成和熔炉相关逻辑
- 基础 Mob 刷新和部分行为
- WiFi 连接和持久化保存
- 串口配网流程
- Windows 本地调试版

当前默认配置比较小：

- 最大玩家数：**5**
- 视距：**2**
- 默认端口：**25565**

这些值和多数开关都定义在 [code/game_types.h](code/game_types.h)。

## 运行方式

### 在 ESP32S3 上运行

默认入口是 [code/code.ino](code/code.ino)。

1. 使用 Arduino IDE 或兼容的 ESP32 开发环境打开 code/ 目录。
2. 安装并选择 ESP32S3 对应的开发板。
3. 选择正确的串口，编译并烧录。
4. 设备启动后会尝试连接已经保存的 WiFi。
5. 联网成功后，服务器开始监听 25565 端口。
6. Minecraft Java 客户端连接设备的 IP 地址。

启动时，串口会输出网络状态、IP 地址和服务器信息，方便排查问题。

### WiFi 配置

当前使用串口 AT 命令完成配网，相关代码在 [code/wifi_config.cpp](code/wifi_config.cpp)。

1. 打开串口监视器。
2. 发送 **#WIFI_UART_CFG#** 进入配网模式。
3. 发送 **AT+HELP** 查看帮助。
4. 扫描 WiFi、填写密码并保存。

常用命令：

~~~text
AT+WSCAN
AT+WSET="<ssid>","<password>"
AT+WSAVE
AT+WINFO?
AT+WEXIT
~~~

代码里也保留了 BOOT 按键触发的配置模式入口。

### 在 Windows 上本地调试

没有 ESP32 开发板也可以运行和学习。仓库提供了 Windows 调试入口，可以先在电脑上验证协议与游戏逻辑：

- 构建脚本：[code/win/build_win.bat](code/win/build_win.bat)
- 入口文件：[code/win/win_main.cpp](code/win/win_main.cpp)

构建脚本会在首次运行时自动准备 w64devkit，然后编译并启动本地版本服务器。

## 代码目录

主要代码位于 code/：

- [code/code.ino](code/code.ino)：Arduino 入口，初始化串口、WiFi、LED 和主循环
- [code/network_layer.cpp](code/network_layer.cpp)：ESP32 网络连接和数据收发
- [code/packet_codec.cpp](code/packet_codec.cpp)：Minecraft 数据包编解码
- [code/mc_server.cpp](code/mc_server.cpp)：连接管理、协议状态机和服务器主体
- [code/procedures.cpp](code/procedures.cpp)：玩家行为、方块交互、Mob 和 Tick
- [code/terrain.cpp](code/terrain.cpp)：地形、区块和基础结构生成
- [code/crafting.cpp](code/crafting.cpp)：合成和熔炉逻辑
- [code/game_state.cpp](code/game_state.cpp)：全局游戏状态
- [code/game_types.h](code/game_types.h)：主要常量、开关和数据结构
- [code/registries.cpp](code/registries.cpp)：协议注册表和静态数据
- [code/wifi_config.cpp](code/wifi_config.cpp)：WiFi 保存和串口配网

辅助目录：

- [code/win/](code/win/)：Windows 调试版
- [Template/](Template/)：最初的工程模板
- [EP1/](EP1/)：EP1 教学内容对应的代码

## 开发说明

- 当前主线代码以 code/ 为准。
- registries.cpp 和 registries.h 体积较大，主要保存协议相关的静态数据。
- 仓库中包含构建产物和调试文件，学习代码时建议先从 code.ino、network_layer.cpp、packet_codec.cpp 和 mc_server.cpp 看起。
- 很多设计是为了节省资源和方便教学，并不追求常见大型服务端的完整抽象。

## 致谢

- 原始项目：[p2r3/bareiron](https://github.com/p2r3/bareiron)
- 原始部分版权归 bareiron 作者和贡献者所有
- ESP32MC 新增与修改部分：GYGKHD，2026 年
